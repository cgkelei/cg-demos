#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <exception>
#include <cstdint>
#include <cassert>
#include <list>
#include <unordered_map>
#include <map>

#include <GL/glew.h>
#include <GL/glut.h>

#include <ft2build.h>
#include "ft2build.h"
#include "freetype/freetype.h"
#include "freetype/ftglyph.h"
#include "freetype/ftoutln.h"
#include "freetype/fttrigon.h"
#include FT_FREETYPE_H

#pragma comment(lib, "freetype.lib")
#pragma comment(lib, "glut32.lib")
#pragma comment(lib, "glew32.lib")
#pragma comment(lib, "opengl32.lib")

using namespace std;

static const int FONT_TEXTURE_SIZE = 1024;
static const int FONT_DPI = 96;

union Pixel32
{
	Pixel32()
		: integer(0) { }
	Pixel32(uint8_t bi, uint8_t gi, uint8_t ri, uint8_t ai = 255)
	{
		b = bi;
		g = gi;
		r = ri;
		a = ai;
	}

	uint8_t integer;

	struct
	{
#ifdef BIG_ENDIAN
		uint8_t a, r, g, b;
#else // BIG_ENDIAN
		uint8_t b, g, r, a;
#endif // BIG_ENDIAN
	};
};

// TGA Header struct to make it simple to dump a TGA to disc.

#if defined(_MSC_VER) || defined(__GNUC__)
#pragma pack(push, 1)
#pragma pack(1)               // Dont pad the following struct.
#endif

struct TGAHeader
{
	uint8_t   idLength,           // Length of optional identification sequence.
		paletteType,        // Is a palette present? (1=yes)
		imageType;          // Image data type (0=none, 1=indexed, 2=rgb,
	// 3=grey, +8=rle packed).
	uint16_t  firstPaletteEntry,  // First palette index, if present.
		numPaletteEntries;  // Number of palette entries, if present.
	uint8_t   paletteBits;        // Number of bits per palette entry.
	uint16_t  x,                  // Horiz. pixel coord. of lower left of image.
		y,                  // Vert. pixel coord. of lower left of image.
		width,              // Image width in pixels.
		height;             // Image height in pixels.
	uint8_t   depth,              // Image color depth (bits per pixel).
		descriptor;         // Image attribute flags.
};

#if defined(_MSC_VER) || defined(__GNUC__)
#pragma pack(pop)
#endif

bool
	WriteTGA(const std::string &filename,
	const Pixel32 *pxl,
	uint16_t width,
	uint16_t height)
{
	std::ofstream file(filename.c_str(), std::ios::binary);
	if (file)
	{
		TGAHeader header;
		memset(&header, 0, sizeof(TGAHeader));
		header.imageType  = 2;
		header.width = width;
		header.height = height;
		header.depth = 32;
		header.descriptor = 0x20;

		file.write((const char *)&header, sizeof(TGAHeader));
		file.write((const char *)pxl, sizeof(Pixel32) * width * height);

		return true;
	}
	return false;
}

void SaveTGA(uint32_t w, uint32_t h, uint8_t* pData)
{
	uint8_t* pixel = pData;
	vector<Pixel32> imageData(w*h);


	for (uint32_t j = 0; j < h; j++)
		for(uint32_t i = 0; i < w; i ++)
		{
			uint8_t b = pixel[((j) * w + i)];
			uint8_t g = pixel[((j) * w + i)];
			uint8_t r = pixel[((j) * w + i)];
			uint8_t a = 255;

			imageData[j*w+i].r = r;
			imageData[j*w+i].g = g;
			imageData[j*w+i].b = b;
			imageData[j*w+i].a = a;
		}

		WriteTGA("char.tga", &imageData[0], w, h);
}

void SaveTexture2D(const char* file, GLuint texID, uint32_t width, uint32_t height)
{
	uint32_t rowPitch;
	
	vector<uint8_t> TextureData(width * height);

	glBindTexture(GL_TEXTURE_2D, texID);
	glGetTexImage(GL_TEXTURE_2D, 0, GL_ALPHA, GL_UNSIGNED_BYTE, &TextureData[0]);
	
	uint8_t* pixel = (uint8_t*)&TextureData[0];
	vector<Pixel32> imageData(width*height);

	auto h = height;
	auto w = width;

	for (uint32_t j = 0; j < h; j++)
		for(uint32_t i = 0; i < w; i ++)
		{
			uint8_t b = pixel[((j) * w + i)];
			uint8_t g = pixel[((j) * w + i)];
			uint8_t r = pixel[((j) * w + i)];
			uint8_t a = 255;

			imageData[j*w+i].r = r;
			imageData[j*w+i].g = g;
			imageData[j*w+i].b = b;
			imageData[j*w+i].a = a;
		}

		WriteTGA(file, &imageData[0], w, h);
}

struct FontGlyph
{
	int32_t Width, Height;
	// Glyph X, Y offset from origin.
	int32_t OffsetX, OffsetY;
	// the horizontal advance value for the glyph. 
	int32_t Advance;
};

struct CharInfo
{
	float u1, v1, u2, v2;
	uint64_t Tick;
};

/// %Font face description.
class FontFace
{
public:
	/// Construct.
	FontFace(const string& fontname, uint32_t fontsize, const wstring& text)
		: CharSize(fontsize), TextureSize(TextureSize)
	{
		CreateFontFace(fontname, fontsize, text);
	}

	/// Destruct.
	~FontFace()
	{
		FT_Done_Face(Face);
		FT_Done_FreeType(Library);
	}

	void CreateFontFace(const string& fontName, uint32_t fontSize, const wstring& text);

	void UpdateTexture(const wstring& text);

	void DrawText(const std::wstring& text, int x, int y, uint32_t fontSize);

	/// Return the glyph structure corresponding to a character.
	const FontGlyph& GetGlyph(unsigned c) const;


	/// Return the kerning for a character and the next character.
	short GetKerning(unsigned c, unsigned d) const;

	/// Glyphs.
	vector<FontGlyph> Glyphs;
	
	map<unsigned, unsigned> GlyphMapping;

	/// Point size.
	int CharSize;
	/// Row height.
	int RowHeight;
	/// Glyph index mapping.
	map<pair<uint32_t, uint32_t>, int32_t> Kerning;
	GLuint mTextureID;


private:

	vector<uint8_t> FontCharData;

	// cached glyph in current texture
	unordered_map<wchar_t, CharInfo> mCharacterCached;

	// free slots in font texture,  [first, second]
	list<std::pair<uint32_t, uint32_t> > mFreeCharacterSlots;

	FT_Face Face;
	FT_Library Library;

	uint32_t TextureSize;
	
	GLuint mVertexBufferID, mIndexBufferID;
};

FontFace* gFont;

wstring gUnicodeString =L"\t���ļ���ʽ��\n\
						 ������ȷ�ͱ�Ϊδ֪\n\
						 �����ߣ�	������ȷ�ͱ�Ϊδ֪\n\
						 ר����		������ȷ�ͱ�Ϊδ֪\n\
						 ����ʱ�䣺01:01:00����1Сʱ��\n\
						 09:09����Сʱ��00:09����1����\n\
						 glBindTexture(GL_TEXTURE_2D,pCharTex->m_texID);\n\
						 glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );\n\
						 glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );\n\
						 glEnable(GL_BLEND);\n\
						 glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);" ;

//wstring gUnicodeString =L"�������ѧ�ţ�21221160";

void init(void)
{
	glShadeModel(GL_SMOOTH);							// Enable Smooth Shading
	glEnable ( GL_COLOR_MATERIAL );
	glColorMaterial ( GL_FRONT, GL_AMBIENT_AND_DIFFUSE );
	glEnable ( GL_TEXTURE_2D );
	glDisable ( GL_CULL_FACE );
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);


	gFont = new FontFace("msyh.ttf", 32, gUnicodeString);
	//glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	//SaveTexture2D("texture1.tga", gFont->mTextureID, FONT_TEXTURE_SIZE, FONT_TEXTURE_SIZE);
}

void reshape( int w, int h )
{
	// Reset the coordinate system before modifying
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// Set the viewport to be the entire window
	glViewport(0, 0, w, h);
	glOrtho(0,w,h,0, -1, 1);
	// Set the clipping volume
	glMatrixMode(GL_MODELVIEW);
}

void display( void )
{
	glClearColor(0.0f , 0.0f , 0.0f , 1.0f);
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glLoadIdentity();
	
	//gFont->DrawText(gUnicodeString, 10, 50, 64);
	gFont->DrawText(L"��", 100, 300, 256);

	/*gFont->DrawText(L"�������123456789", 10, 100, 64);
	gFont->DrawText(L"����ֻ˵���������֡���Ҫ��ҵ���Ǳ�˵��ҵ�ܼ��ʧ���ʺܸߣ���ɹ�������", 10, 150, 32);
	gFont->DrawText(L"�����������£���Ը������Ӳ�ң����������룬Ը���ܳ���", 10, 200, 32);
	gFont->DrawText(L"��֧��ͨ���������ɹ�����#С���ֻ�1S�ഺ��#���û��Ѿ���", 10, 250, 32);
	gFont->DrawText(L"�Ї��L����Y����������", 10, 300, 32);*/

	glutSwapBuffers();
}

void keyboard ( unsigned char key, int x, int y )  // Create Keyboard Function
{
	switch ( key ) {
	case 27:        // When Escape Is Pressed...
		exit ( 0 );   // Exit The Program
		break;        // Ready For Next Case
	default:        // Now Wrap It Up
		break;
	}
}

void arrow_keys ( int a_keys, int x, int y )  // Create Special Function (required for arrow keys)
{
	switch ( a_keys ) {
	case GLUT_KEY_UP:     // When Up Arrow Is Pressed...
		glutFullScreen ( ); // Go Into Full Screen Mode
		break;
	case GLUT_KEY_DOWN:               // When Down Arrow Is Pressed...
		glutReshapeWindow ( 800, 800 ); // Go Into A 500 By 500 Window
		break;
	default:
		break;
	}
}

int main ( int argc, char** argv )   // Create Main Function For Bringing It All Together
{
	glutInit            ( &argc, argv ); // Erm Just Write It =)
	glutInitDisplayMode ( GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA ); // Display Mode
	glutInitWindowPosition (0,0);
	glutInitWindowSize  ( 500, 500 ); // If glutFullScreen wasn't called this is the window size
	glutCreateWindow    ( "NeHe Lesson 6- Ported by Rustad" ); // Window Title (argv[0] for current directory as title)
	
	glewInit();
	
	init ();
	//glutFullScreen      ( );          // Put Into Full Screen
	glutDisplayFunc     ( display );  // Matching Earlier Functions To Their Counterparts
	glutReshapeFunc     ( reshape );
	glutKeyboardFunc    ( keyboard );
	glutSpecialFunc     ( arrow_keys );
	glutIdleFunc			 ( display );
	glutMainLoop        ( );          // Initialize The Main Loop
	return 1;
}

void FontFace::UpdateTexture( const wstring& text )
{
	static int64_t tick = 0;
	tick++;

	FT_Error error;

	const uint32_t numCharPerRow = TextureSize / CharSize;
	const uint32_t totalNumChars = numCharPerRow * numCharPerRow;

	glBindTexture(GL_TEXTURE_2D, mTextureID);

	for (auto charIter = text.begin(); charIter != text.end(); ++charIter)
	{
		wchar_t ch = *charIter;

		auto found = mCharacterCached.find(ch);

		if (found != mCharacterCached.end())
		{
			// already exits in texture, add use tick
			found->second.Tick = tick;
		}
		else
		{
			error = FT_Load_Char(Face, ch, FT_LOAD_DEFAULT);

			FT_GlyphSlot slot = Face->glyph;

			if (!error)
			{
				uint32_t charPosX, charPosY;
				CharInfo charInfo;

				if (mCharacterCached.size() < totalNumChars)
				{
					std::pair<uint32_t, uint32_t>& firstFreeSlots = mFreeCharacterSlots.front();

					const uint32_t slot = firstFreeSlots.first;

					charPosY = slot / numCharPerRow;
					charPosX = slot - charPosY * numCharPerRow;

					charPosX *= CharSize;
					charPosY *= CharSize;

					charInfo.u1 = (static_cast<float>(charPosX) / TextureSize);
					charInfo.v1 = (static_cast<float>(charPosY) / TextureSize);

					++ firstFreeSlots.first;
					if (firstFreeSlots.first == firstFreeSlots.second)
					{
						mFreeCharacterSlots.pop_front();
					}
				}
				else
				{
					auto minIter = mCharacterCached.begin();
					uint64_t minTick = minIter->second.Tick;	
					for (auto iter = mCharacterCached.begin(); iter != mCharacterCached.end(); ++iter)
					{
						if (iter->second.Tick < minTick)
						{
							minTick = iter->second.Tick;
							minIter = iter;
						}
					}

					charPosX =  static_cast<int32_t>(minIter->second.u1 * TextureSize);
					charPosY = static_cast<int32_t>(minIter->second.v1 * TextureSize);

					charInfo.u1 = (minIter->second.u1);
					charInfo.v1 = (minIter->second.v1);

					//delete min one
					mCharacterCached.erase(minIter);

					// remove those character
					auto delIter = mCharacterCached.begin();
					while(delIter != mCharacterCached.end())
					{
						if (delIter->second.Tick == minTick)
						{
							// push this character slot to free list
							const uint32_t x = static_cast<int32_t>(delIter->second.u1 * numCharPerRow);
							const uint32_t y = static_cast<int32_t>(delIter->second.v1 * numCharPerRow);
							const uint32_t slotIndex = y * numCharPerRow + x;

							auto slotIter = mFreeCharacterSlots.begin();
							while ((slotIter != mFreeCharacterSlots.end()) && (slotIter->second <= slotIndex))
							{
								++ slotIter;
							}
							mFreeCharacterSlots.insert(slotIter, std::make_pair(slotIndex, slotIndex + 1));	// only one character is freed

							
							wchar_t decCh = delIter->first;
							mCharacterCached.erase(delIter++);
						}
						else
						{
							++delIter;
						}
					}

					// connect all slot if they are adjacent
					for (auto iter = mFreeCharacterSlots.begin(); iter != mFreeCharacterSlots.end(); )
					{
						auto next = iter; ++next;

						if ( (next != mFreeCharacterSlots.end()) && iter->second == next->first )
						{
							iter->second = next->second;
							mFreeCharacterSlots.erase(next);
						}
						else
						{
							++iter;
						}
					}
				}

				charInfo.u2 = (charInfo.u1 + static_cast<float>(slot->metrics.width >> 6) / TextureSize);
				charInfo.v2 = (charInfo.v1 + static_cast<float>(slot->metrics.height >> 6) / TextureSize);
				charInfo.Tick = tick;
				
				// add new GlyphMapping if doesn't exit
				if (GlyphMapping.find(ch) == GlyphMapping.end())
				{
					FontGlyph newGlyph;
					newGlyph.Advance = slot->advance.x >> 6;
					newGlyph.Width = slot->metrics.width >> 6;
					newGlyph.Height = slot->metrics.height >> 6;
					newGlyph.OffsetX = slot->metrics.horiBearingX >> 6;
					newGlyph.OffsetY = slot->metrics.horiBearingY >> 6;

					GlyphMapping.insert(make_pair((unsigned)ch, Glyphs.size()));
					Glyphs.push_back(newGlyph);
				}

				// cache this character
				mCharacterCached.insert(std::make_pair(ch, charInfo));

				// convert into bitmap
				error = FT_Render_Glyph( slot,  FT_RENDER_MODE_NORMAL );
				if (!error)
				{
					memset(&FontCharData[0], 0, FontCharData.size());
					for (int32_t y = 0; y < slot->bitmap.rows; ++y)
					{
						unsigned char* src = slot->bitmap.buffer + slot->bitmap.pitch * y;
						unsigned char* dest = &FontCharData[0] + CharSize * y;

						for (int32_t x = 0; x < slot->bitmap.width; ++x)
						{
							dest[x] = src[x];
						}
					}

					/*SaveTGA(CharSize, CharSize, &FontCharData[0]);*/
					glTexSubImage2D(GL_TEXTURE_2D, 0, charPosX, charPosY, CharSize, CharSize, 
						GL_ALPHA, GL_UNSIGNED_BYTE, &FontCharData[0]);					
				}	
			}
		}
	}

	glBindTexture(GL_TEXTURE_2D, 0);
}

void FontFace::CreateFontFace( const string& fontName, uint32_t fontSize, const wstring& text )
{
	FT_Error error;

	if (FT_Init_FreeType( &Library )) 
	{
		throw std::runtime_error("FT_Init_FreeType failed");
	}

	error = FT_New_Face( Library, fontName.c_str(), 0, &Face );
	if (error)
	{
		throw std::runtime_error("Could not create font face");
	}

	FT_F26Dot6 ftSize = (FT_F26Dot6)(fontSize * (1 << 6));
	//error = FT_Set_Char_Size(face, 0, ftSize, FONT_DPI, FONT_DPI);
	error = FT_Set_Pixel_Sizes(Face, 0, fontSize);

	if (error)
	{
		FT_Done_Face(Face);
		throw std::runtime_error("Could not set font point size");
	}

	// Set character encoding
	FT_Select_Charmap(Face,FT_ENCODING_UNICODE);

	RowHeight = Face->height >> 6;
	TextureSize = FONT_TEXTURE_SIZE / CharSize * CharSize;

	// Create font texture
	glGenTextures(1,&mTextureID);
	glBindTexture(GL_TEXTURE_2D,mTextureID);

	glTexImage2D( GL_TEXTURE_2D, 0, GL_ALPHA, TextureSize, TextureSize, 0,
		GL_ALPHA,GL_UNSIGNED_BYTE,NULL);

	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
	glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );

	FontCharData.resize(CharSize * CharSize);

	mFreeCharacterSlots.push_back(std::make_pair(0, TextureSize * TextureSize / CharSize / CharSize));

	UpdateTexture(text);
}

const FontGlyph& FontFace::GetGlyph( unsigned c ) const
{
	auto found = GlyphMapping.find(c);
	if (found != GlyphMapping.end())
	{
		return Glyphs[found->second];
	}
	else
		throw std::exception("Glyph doesn't exit");
}

void FontFace::DrawText( const std::wstring& text, int sx, int sy, uint32_t fontSize)
{
	UpdateTexture(text);
	
	glBindTexture(GL_TEXTURE_2D, mTextureID);
	glActiveTexture(GL_TEXTURE0);

	float x = sx;
	float y = sy;

	const float scale = float(fontSize) / float(CharSize);

	glColor3f(1, 0, 0);
	glBegin ( GL_QUADS );

	for (auto iter = text.begin(); iter != text.end(); ++iter)
	{
		wchar_t ch = *iter;

		if (ch == L'\n')
		{
			y += RowHeight * scale;
			x = sx * scale;
		}
		else
		{
			const FontGlyph& glyph = Glyphs[GlyphMapping[ch]];

			const CharInfo& charInfo = mCharacterCached[ch];

			int ch_x = x + glyph.OffsetX * scale;
			int ch_y = y - glyph.OffsetY * scale;

			// top left
			glTexCoord2f(charInfo.u1, charInfo.v1); glVertex3f(ch_x, ch_y,  1.0f);

			// top right
			glTexCoord2f(charInfo.u2, charInfo.v1); glVertex3f(ch_x + glyph.Width * scale, ch_y    ,  1.0f);

			// bottom right
			glTexCoord2f(charInfo.u2, charInfo.v2);  glVertex3f(ch_x + glyph.Width* scale , ch_y + glyph.Height* scale,  1.0f);

			// bottom left
			glTexCoord2f(charInfo.u1, charInfo.v2); glVertex3f(ch_x, ch_y + glyph.Height* scale,  1.0f);

			x += glyph.Advance * scale;
		}
	}

	//glVertex3f(100, 100,  1.0f);
	//glColor3f(1, 1, 0);
	//glVertex3f(200, 100,  1.0f);
	//glColor3f(1, 1, 1);
	//glVertex3f(200, 200,  1.0f);
	//glColor3f(1, 0, 1);
	//glVertex3f(100, 200,  1.0f);

	glEnd();
}
